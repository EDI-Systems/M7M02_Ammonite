/******************************************************************************
Filename    : rmp_platform_a7m_rvm_conf.h
Author      : The RME project generator.
Date        : 13/09/2019
License     : LGPL v3+; see COPYING for details.
Description : The chip selection header.
******************************************************************************/

/* Platform Includes *********************************************************/
#include "Platform/A7M_RVM/Chips/STM32F767IG/rmp_platform_STM32F767IG_rvm.h"
/* End Platform Includes *****************************************************/

/* End Of File ***************************************************************/

/* Copyright (C) Evo-Devo Instrum. All rights reserved ***********************/

