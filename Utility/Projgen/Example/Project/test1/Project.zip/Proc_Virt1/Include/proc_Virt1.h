/******************************************************************************
Filename    : proc_Virt1.h
Author      : The RME project generator.
Date        : 13/09/2019
License     : LGPL v3+; see COPYING for details.
Description : The user kernel object header.
******************************************************************************/

/* Defines *******************************************************************/
#ifndef __PROC_Virt1_H__
#define __PROC_Virt1_H__
/* Ports */

/* Receive endpoints */

/* Send endpoints */
#define SEND_RECV1                                      (2)

/* Vector endpoints */
#define RVM_VIRT_REG_BASE                               (0x2005F400)
#define RVM_VIRT_PARAM_BASE                             (0x2005F600)
/* Virtual vector total number */
#define RVM_VIRT_VECT_NUM                               (100)
/* Virtual vector bitmap address & size */
#define RVM_VIRT_VCTF_BASE                              (0x2005F700)
#define RVM_VIRT_VCTF_SIZE                              (0x100)
/* Virtual register address */
#endif /* __PROC_Virt1_H__ */
/* End Defines ***************************************************************/

/* End Of File ***************************************************************/

/* Copyright (C) Evo-Devo Instrum. All rights reserved ***********************/

