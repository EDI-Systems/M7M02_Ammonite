/******************************************************************************
Filename    : proc_Proc1.h
Author      : The RME project generator.
Date        : 13/09/2019
License     : LGPL v3+; see COPYING for details.
Description : The user kernel object header.
******************************************************************************/

/* Defines *******************************************************************/
#ifndef __PROC_Proc1_H__
#define __PROC_Proc1_H__
/* Ports */
#define PORT_INV1                                       (1)

/* Receive endpoints */
#define RECV_RECV1                                      (2)

/* Send endpoints */

/* Vector endpoints */
#endif /* __PROC_Proc1_H__ */
/* End Defines ***************************************************************/

/* End Of File ***************************************************************/

/* Copyright (C) Evo-Devo Instrum. All rights reserved ***********************/

