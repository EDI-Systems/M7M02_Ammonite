/******************************************************************************
Filename    : proc_Proc2.h
Author      : The RME project generator.
Date        : 13/09/2019
License     : LGPL v3+; see COPYING for details.
Description : The user kernel object header.
******************************************************************************/

/* Defines *******************************************************************/
#ifndef __PROC_Proc2_H__
#define __PROC_Proc2_H__
/* Ports */

/* Receive endpoints */
#define RECV_RECV1                                      (1)

/* Send endpoints */
#define SEND_RECV1                                      (2)

/* Vector endpoints */
#define VECT_TIM1                                       (3)
#endif /* __PROC_Proc2_H__ */
/* End Defines ***************************************************************/

/* End Of File ***************************************************************/

/* Copyright (C) Evo-Devo Instrum. All rights reserved ***********************/

