/******************************************************************************
Filename    : rme_user.c
Author      : The RME project generator.
Date        : 13/09/2019
License     : LGPL v3+; see COPYING for details.
Description : The user hook file.
******************************************************************************/

/* Includes ******************************************************************/
#define __HDR_DEFS__
#include "Platform/A7M/rme_platform_a7m.h"
#include "Kernel/rme_kernel.h"
#undef __HDR_DEFS__

#define __HDR_STRUCTS__
#include "Platform/A7M/rme_platform_a7m.h"
#include "Kernel/rme_kernel.h"
#undef __HDR_STRUCTS__

#define __HDR_PUBLIC_MEMBERS__
#include "Platform/A7M/rme_platform_a7m.h"
#include "Kernel/rme_kernel.h"
#undef __HDR_PUBLIC_MEMBERS__

#include "rme_boot.h"
/* End Includes **************************************************************/

/* Public C Function Prototypes **********************************************/
void RME_Boot_Pre_Init(void);
void RME_Boot_Post_Init(void);
rme_ptr_t RME_Vect_TIM1_User(rme_ptr_t Int_Num);
/* End Public C Function Prototypes ******************************************/

/* Begin Function:RME_Boot_Pre_Init *******************************************
Description : Initialize critical hardware before any kernel initialization takes place.
Input       : None.
Output      : None.
Return      : None.
******************************************************************************/
void RME_Boot_Pre_Init(void)
{
    /* Add code here */
}
/* End Function:RME_Boot_Pre_Init ********************************************/

/* Begin Function:RME_Boot_Post_Init ******************************************
Description : Initialize hardware after all kernel initialization took place.
Input       : None.
Output      : None.
Return      : None.
******************************************************************************/
void RME_Boot_Post_Init(void)
{
    /* Add code here */
}
/* End Function:RME_Boot_Post_Init *******************************************/

/* Begin Function:RME_Vect_TIM1_User ******************************************
Description : The user top-half interrupt handler for vector.
Input       : rme_ptr_t Int_Num - The interrupt number.
Output      : None.
Return      : rme_ptr_t - The number of signals to send to the generic vector endpoint.
******************************************************************************/
rme_ptr_t RME_Vect_TIM1_User(rme_ptr_t Int_Num)

{
    /* Add code here */

    return 0;
}
/* End Function:RME_Vect_TIM1_User *******************************************/

/* End Of File ***************************************************************/

/* Copyright (C) Evo-Devo Instrum. All rights reserved ***********************/

