/******************************************************************************
Filename    : rvm_boot.c
Author      : The RME project generator.
Date        : 13/09/2019
License     : LGPL v3+; see COPYING for details.
Description : The boot-time initialization file.
******************************************************************************/

/* Includes ******************************************************************/
#include "rvm.h"

#define __HDR_DEFS__
#include "Platform/A7M/rvm_platform_a7m.h"
#include "Init/rvm_syssvc.h"
#include "Init/rvm_init.h"
#include "Init/rvm_hyper.h"
#undef __HDR_DEFS__

#define __HDR_STRUCTS__
#include "Platform/A7M/rvm_platform_a7m.h"
#include "Init/rvm_syssvc.h"
#include "Init/rvm_init.h"
#include "Init/rvm_hyper.h"
#undef __HDR_STRUCTS__

#define __HDR_PUBLIC_MEMBERS__
#include "Platform/A7M/rvm_platform_a7m.h"
#include "Init/rvm_syssvc.h"
#include "Init/rvm_init.h"
#include "Init/rvm_hyper.h"
#undef __HDR_PUBLIC_MEMBERS__

#include "rvm_boot.h"
/* End Includes **************************************************************/

/* Public Global Varibles ****************************************************/
struct RVM_Virt RVM_Virt_DB[1];
const struct RVM_Virt_Map RVM_Virt_Map_DB[1]=
{
{(rvm_s8_t*)"Virt1", 5, 10, 100, 100,
 (struct RVM_Regs*)0x2005F400, (struct RVM_Param*)0x2005F600,
 (struct RVM_Vect_Flag*)0x2005F700, 0x8040040, RVM_CAPID(RVM_BOOT_CTVIRTEP0,0),
 RVM_PROC_VIRT1_THD_VECT, RVM_PROC_VIRT1_THD_VECT, 0x8040000, 0x2005FC00, 0x400,
 RVM_PROC_VIRT1_THD_USER, RVM_PROC_VIRT1_THD_USER, 0x8040020, 0x2005F800, 0x400},
};
/* End Public Global Varibles ************************************************/

/* Private C Function Prototypes *********************************************/
/* Kernel object creation */
static void RVM_Boot_Virtep_Crt(void);
static void RVM_Boot_Captbl_Crt(void);
static void RVM_Boot_Pgtbl_Crt(void);
static void RVM_Boot_Proc_Crt(void);
static void RVM_Boot_Inv_Crt(void);
static void RVM_Boot_Recv_Crt(void);

/* Kernel object initialization */
static void RVM_Boot_Virtcap_Init(void);
static void RVM_Boot_Captbl_Init(void);
static void RVM_Boot_Pgtbl_Init(void);
static void RVM_Boot_Thd_Init(void);
static void RVM_Boot_Inv_Init(void);
/* End Private C Function Prototypes *****************************************/

/* Public C Function Prototypes **********************************************/
void RVM_Boot_Kobj_Crt(void);
void RVM_Boot_Kobj_Init(void);
/* End Public C Function Prototypes ******************************************/

/* Begin Function:RVM_Boot_Virtep_Crt *****************************************
Description : Create all virtual machine vector endpoints at boot-time.
Input       : None.
Output      : None.
Return      : None.
******************************************************************************/
void RVM_Boot_Virtep_Crt(void)
{
    rvm_ptr_t Cur_Addr;

    Cur_Addr=0xB60;

    /* Create all the virtual machine endpoint capability tables first */
    RVM_ASSERT(RVM_Captbl_Crt(RVM_BOOT_CAPTBL, RVM_BOOT_INIT_KMEM, RVM_BOOT_CTVIRTEP0, Cur_Addr, 1)==0);
    RVM_LOG_SISUS("Init:Created virtual machine endpoint capability table CID ", RVM_BOOT_CTVIRTEP0, " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_CAPTBL_SIZE(1));

    /* Then the endpoints themselves */
    RVM_ASSERT(RVM_Sig_Crt(RVM_BOOT_CTVIRTEP0, RVM_BOOT_INIT_KMEM, 0, Cur_Addr)==0);
    RVM_LOG_SISUS("Init:Created virtual machine endpoint CID ", RVM_CAPID(RVM_BOOT_CTVIRTEP0,0), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_SIG_SIZE);

    RVM_ASSERT(Cur_Addr==0xB90);
}
/* End Function:RVM_Boot_Virtep_Crt ******************************************/

/* Begin Function:RVM_Boot_Captbl_Crt *****************************************
Description : Create all capability tables at boot-time.
Input       : None.
Output      : None.
Return      : None.
******************************************************************************/
void RVM_Boot_Captbl_Crt(void)
{
    rvm_ptr_t Cur_Addr;

    Cur_Addr=0xB90;

    /* Create all the capability table capability tables first */
    RVM_ASSERT(RVM_Captbl_Crt(RVM_BOOT_CAPTBL, RVM_BOOT_INIT_KMEM, RVM_BOOT_CTCAPTBL0, Cur_Addr, 3)==0);
    RVM_LOG_SISUS("Init:Created capability table capability table CID ", RVM_BOOT_CTCAPTBL0, " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_CAPTBL_SIZE(3));

    /* Then the capability tables themselves */
    RVM_ASSERT(RVM_Captbl_Crt(RVM_BOOT_CTCAPTBL0, RVM_BOOT_INIT_KMEM, 0, Cur_Addr, 13)==0);
    RVM_LOG_SISUS("Init:Created capability table RVM_CAPTBL_PROC1 CID ", RVM_CAPID(RVM_BOOT_CTCAPTBL0,0), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_CAPTBL_SIZE(13));
    RVM_ASSERT(RVM_Captbl_Crt(RVM_BOOT_CTCAPTBL0, RVM_BOOT_INIT_KMEM, 1, Cur_Addr, 5)==0);
    RVM_LOG_SISUS("Init:Created capability table RVM_CAPTBL_PROC2 CID ", RVM_CAPID(RVM_BOOT_CTCAPTBL0,1), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_CAPTBL_SIZE(5));
    RVM_ASSERT(RVM_Captbl_Crt(RVM_BOOT_CTCAPTBL0, RVM_BOOT_INIT_KMEM, 2, Cur_Addr, 5)==0);
    RVM_LOG_SISUS("Init:Created capability table RVM_CAPTBL_VIRT1 CID ", RVM_CAPID(RVM_BOOT_CTCAPTBL0,2), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_CAPTBL_SIZE(5));

    RVM_ASSERT(Cur_Addr==0xED0);
}
/* End Function:RVM_Boot_Captbl_Crt ******************************************/

/* Begin Function:RVM_Boot_Pgtbl_Crt ******************************************
Description : Create all page tables at boot-time.
Input       : None.
Output      : None.
Return      : None.
******************************************************************************/
void RVM_Boot_Pgtbl_Crt(void)
{
    rvm_ptr_t Cur_Addr;

    Cur_Addr=0xED0;

    /* Create all the page tables capability tables first */
    RVM_ASSERT(RVM_Captbl_Crt(RVM_BOOT_CAPTBL, RVM_BOOT_INIT_KMEM, RVM_BOOT_CTPGTBL0, Cur_Addr, 10)==0);
    RVM_LOG_SISUS("Init:Created page table capability table CID ", RVM_BOOT_CTPGTBL0, " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_CAPTBL_SIZE(10));

    /* Then the page tables themselves */
    RVM_ASSERT(RVM_Pgtbl_Crt(RVM_BOOT_CTPGTBL0, RVM_BOOT_INIT_KMEM, 0, Cur_Addr, 0x0, 1, 29, 3)==0);
    RVM_LOG_SISUS("Init:Created page table RVM_PGTBL_PROC1_N0 CID ", RVM_CAPID(RVM_BOOT_CTPGTBL0,0), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=0x80;
    RVM_ASSERT(RVM_Pgtbl_Crt(RVM_BOOT_CTPGTBL0, RVM_BOOT_INIT_KMEM, 1, Cur_Addr, 0x8020000, 0, 16, 0)==0);
    RVM_LOG_SISUS("Init:Created page table RVM_PGTBL_PROC1_N1 CID ", RVM_CAPID(RVM_BOOT_CTPGTBL0,1), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=0x20;
    RVM_ASSERT(RVM_Pgtbl_Crt(RVM_BOOT_CTPGTBL0, RVM_BOOT_INIT_KMEM, 2, Cur_Addr, 0x20020000, 0, 16, 1)==0);
    RVM_LOG_SISUS("Init:Created page table RVM_PGTBL_PROC1_N2 CID ", RVM_CAPID(RVM_BOOT_CTPGTBL0,2), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=0x20;
    RVM_ASSERT(RVM_Pgtbl_Crt(RVM_BOOT_CTPGTBL0, RVM_BOOT_INIT_KMEM, 3, Cur_Addr, 0xF0000000, 0, 16, 0)==0);
    RVM_LOG_SISUS("Init:Created page table RVM_PGTBL_PROC1_N3 CID ", RVM_CAPID(RVM_BOOT_CTPGTBL0,3), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=0x20;
    RVM_ASSERT(RVM_Pgtbl_Crt(RVM_BOOT_CTPGTBL0, RVM_BOOT_INIT_KMEM, 4, Cur_Addr, 0x0, 1, 27, 3)==0);
    RVM_LOG_SISUS("Init:Created page table RVM_PGTBL_PROC2_N0 CID ", RVM_CAPID(RVM_BOOT_CTPGTBL0,4), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=0x80;
    RVM_ASSERT(RVM_Pgtbl_Crt(RVM_BOOT_CTPGTBL0, RVM_BOOT_INIT_KMEM, 5, Cur_Addr, 0x8030000, 0, 16, 0)==0);
    RVM_LOG_SISUS("Init:Created page table RVM_PGTBL_PROC2_N1 CID ", RVM_CAPID(RVM_BOOT_CTPGTBL0,5), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=0x20;
    RVM_ASSERT(RVM_Pgtbl_Crt(RVM_BOOT_CTPGTBL0, RVM_BOOT_INIT_KMEM, 6, Cur_Addr, 0x20040000, 0, 16, 0)==0);
    RVM_LOG_SISUS("Init:Created page table RVM_PGTBL_PROC2_N2 CID ", RVM_CAPID(RVM_BOOT_CTPGTBL0,6), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=0x20;
    RVM_ASSERT(RVM_Pgtbl_Crt(RVM_BOOT_CTPGTBL0, RVM_BOOT_INIT_KMEM, 7, Cur_Addr, 0x0, 1, 27, 3)==0);
    RVM_LOG_SISUS("Init:Created page table RVM_PGTBL_VIRT1_N0 CID ", RVM_CAPID(RVM_BOOT_CTPGTBL0,7), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=0x80;
    RVM_ASSERT(RVM_Pgtbl_Crt(RVM_BOOT_CTPGTBL0, RVM_BOOT_INIT_KMEM, 8, Cur_Addr, 0x8040000, 0, 16, 0)==0);
    RVM_LOG_SISUS("Init:Created page table RVM_PGTBL_VIRT1_N1 CID ", RVM_CAPID(RVM_BOOT_CTPGTBL0,8), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=0x20;
    RVM_ASSERT(RVM_Pgtbl_Crt(RVM_BOOT_CTPGTBL0, RVM_BOOT_INIT_KMEM, 9, Cur_Addr, 0x20050000, 0, 16, 0)==0);
    RVM_LOG_SISUS("Init:Created page table RVM_PGTBL_VIRT1_N2 CID ", RVM_CAPID(RVM_BOOT_CTPGTBL0,9), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=0x20;

    RVM_ASSERT(Cur_Addr==0x1270);
}
/* End Function:RVM_Boot_Pgtbl_Crt *******************************************/

/* Begin Function:RVM_Boot_Proc_Crt *******************************************
Description : Create all processes at boot-time.
Input       : None.
Output      : None.
Return      : None.
******************************************************************************/
void RVM_Boot_Proc_Crt(void)
{
    rvm_ptr_t Cur_Addr;

    Cur_Addr=0x1270;

    /* Create all the process capability tables first */
    RVM_ASSERT(RVM_Captbl_Crt(RVM_BOOT_CAPTBL, RVM_BOOT_INIT_KMEM, RVM_BOOT_CTPROC0, Cur_Addr, 3)==0);
    RVM_LOG_SISUS("Init:Created process capability table CID ", RVM_BOOT_CTPROC0, " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_CAPTBL_SIZE(3));

    /* Then the processes themselves */
    RVM_ASSERT(RVM_Proc_Crt(RVM_BOOT_CTPROC0, RVM_BOOT_INIT_KMEM, 0, RVM_CAPTBL_PROC1, RVM_PGTBL_PROC1_N0, Cur_Addr)==0);
    RVM_LOG_SISUS("Init:Created process RVM_PROC_PROC1 CID ", RVM_CAPID(RVM_BOOT_CTPROC0,0), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_PROC_SIZE);
    RVM_ASSERT(RVM_Proc_Crt(RVM_BOOT_CTPROC0, RVM_BOOT_INIT_KMEM, 1, RVM_CAPTBL_PROC2, RVM_PGTBL_PROC2_N0, Cur_Addr)==0);
    RVM_LOG_SISUS("Init:Created process RVM_PROC_PROC2 CID ", RVM_CAPID(RVM_BOOT_CTPROC0,1), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_PROC_SIZE);
    RVM_ASSERT(RVM_Proc_Crt(RVM_BOOT_CTPROC0, RVM_BOOT_INIT_KMEM, 2, RVM_CAPTBL_VIRT1, RVM_PGTBL_VIRT1_N0, Cur_Addr)==0);
    RVM_LOG_SISUS("Init:Created process RVM_PROC_VIRT1 CID ", RVM_CAPID(RVM_BOOT_CTPROC0,2), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_PROC_SIZE);

    RVM_ASSERT(Cur_Addr==0x1300);
}
/* End Function:RVM_Boot_Proc_Crt ********************************************/

/* Begin Function:RVM_Boot_Thd_Crt ********************************************
Description : Create all threads at boot-time.
Input       : None.
Output      : None.
Return      : None.
******************************************************************************/
void RVM_Boot_Thd_Crt(void)
{
    rvm_ptr_t Cur_Addr;

    Cur_Addr=0x1300;

    /* Create all the thread capability tables first */
    RVM_ASSERT(RVM_Captbl_Crt(RVM_BOOT_CAPTBL, RVM_BOOT_INIT_KMEM, RVM_BOOT_CTTHD0, Cur_Addr, 4)==0);
    RVM_LOG_SISUS("Init:Created thread capability table CID ", RVM_BOOT_CTTHD0, " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_CAPTBL_SIZE(4));

    /* Then the threads themselves */
    RVM_ASSERT(RVM_Thd_Crt(RVM_BOOT_CTTHD0, RVM_BOOT_INIT_KMEM, 0, RVM_PROC_PROC1, 17, Cur_Addr)==0);
    RVM_LOG_SISUS("Init:Created thread RVM_PROC_PROC1_THD_THD1 CID ", RVM_CAPID(RVM_BOOT_CTTHD0,0), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_THD_SIZE);
    RVM_ASSERT(RVM_Thd_Crt(RVM_BOOT_CTTHD0, RVM_BOOT_INIT_KMEM, 1, RVM_PROC_PROC2, 16, Cur_Addr)==0);
    RVM_LOG_SISUS("Init:Created thread RVM_PROC_PROC2_THD_THD1 CID ", RVM_CAPID(RVM_BOOT_CTTHD0,1), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_THD_SIZE);
    RVM_ASSERT(RVM_Thd_Crt(RVM_BOOT_CTTHD0, RVM_BOOT_INIT_KMEM, 2, RVM_PROC_VIRT1, 3, Cur_Addr)==0);
    RVM_LOG_SISUS("Init:Created thread RVM_PROC_VIRT1_THD_VECT CID ", RVM_CAPID(RVM_BOOT_CTTHD0,2), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_THD_SIZE);
    RVM_ASSERT(RVM_Thd_Crt(RVM_BOOT_CTTHD0, RVM_BOOT_INIT_KMEM, 3, RVM_PROC_VIRT1, 2, Cur_Addr)==0);
    RVM_LOG_SISUS("Init:Created thread RVM_PROC_VIRT1_THD_USER CID ", RVM_CAPID(RVM_BOOT_CTTHD0,3), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_THD_SIZE);

    RVM_ASSERT(Cur_Addr==0x1680);
}
/* End Function:RVM_Boot_Thd_Crt *********************************************/

/* Begin Function:RVM_Boot_Inv_Crt ********************************************
Description : Create all invocations at boot-time.
Input       : None.
Output      : None.
Return      : None.
******************************************************************************/
void RVM_Boot_Inv_Crt(void)
{
    rvm_ptr_t Cur_Addr;

    Cur_Addr=0x1680;

    /* Create all the invocation capability tables first */
    RVM_ASSERT(RVM_Captbl_Crt(RVM_BOOT_CAPTBL, RVM_BOOT_INIT_KMEM, RVM_BOOT_CTINV0, Cur_Addr, 1)==0);
    RVM_LOG_SISUS("Init:Created invocation capability table CID ", RVM_BOOT_CTINV0, " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_CAPTBL_SIZE(1));

    /* Then the invocations themselves */
    RVM_ASSERT(RVM_Inv_Crt(RVM_BOOT_CTINV0, RVM_BOOT_INIT_KMEM, 0, RVM_PROC_PROC2, Cur_Addr)==0);
    RVM_LOG_SISUS("Init:Created invocation RVM_PROC_PROC2_INV_INV1 CID ", RVM_CAPID(RVM_BOOT_CTINV0,0), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_INV_SIZE);

    RVM_ASSERT(Cur_Addr==0x16D0);
}
/* End Function:RVM_Boot_Inv_Crt *********************************************/

/* Begin Function:RVM_Boot_Recv_Crt *******************************************
Description : Create all receive endpoints at boot-time.
Input       : None.
Output      : None.
Return      : None.
******************************************************************************/
void RVM_Boot_Recv_Crt(void)
{
    rvm_ptr_t Cur_Addr;

    Cur_Addr=0x16D0;

    /* Create all the receive endpoint capability tables first */
    RVM_ASSERT(RVM_Captbl_Crt(RVM_BOOT_CAPTBL, RVM_BOOT_INIT_KMEM, RVM_BOOT_CTRECV0, Cur_Addr, 2)==0);
    RVM_LOG_SISUS("Init:Created receive endpoint capability table CID ", RVM_BOOT_CTRECV0, " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_CAPTBL_SIZE(2));

    /* Then the receive endpoints themselves */
    RVM_ASSERT(RVM_Sig_Crt(RVM_BOOT_CTRECV0, RVM_BOOT_INIT_KMEM, 0, Cur_Addr)==0);
    RVM_LOG_SISUS("Init:Created receive endpoint RVM_PROC_PROC1_RECV_RECV1 CID ", RVM_CAPID(RVM_BOOT_CTRECV0,0), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_SIG_SIZE);
    RVM_ASSERT(RVM_Sig_Crt(RVM_BOOT_CTRECV0, RVM_BOOT_INIT_KMEM, 1, Cur_Addr)==0);
    RVM_LOG_SISUS("Init:Created receive endpoint RVM_PROC_PROC2_RECV_RECV1 CID ", RVM_CAPID(RVM_BOOT_CTRECV0,1), " @ address 0x", Cur_Addr, "\r\n");
    Cur_Addr+=RVM_KOTBL_ROUND(RVM_SIG_SIZE);

    RVM_ASSERT(Cur_Addr==0x1730);
}
/* End Function:RVM_Boot_Recv_Crt ********************************************/

/* Begin Function:RVM_Boot_Kobj_Crt *******************************************
Description : Create all kernel objects at boot-time.
Input       : None.
Output      : None.
Return      : None.
******************************************************************************/
void RVM_Boot_Kobj_Crt(void)
{
    RVM_Boot_Virtep_Crt();
    RVM_Boot_Captbl_Crt();
    RVM_Boot_Pgtbl_Crt();
    RVM_Boot_Proc_Crt();
    RVM_Boot_Thd_Crt();
    RVM_Boot_Inv_Crt();
    RVM_Boot_Recv_Crt();
}
/* End Function:RVM_Boot_Kobj_Crt ********************************************/

/* Begin Function:RVM_Boot_Virtcap_Init ***************************************
Description : Initialize all virtual machine capability table special contents.
Input       : None.
Output      : None.
Return      : None.
******************************************************************************/
void RVM_Boot_Virtcap_Init(void)
{
    /* Initializing virtual machine: Virt1 */
    /* System call endpoint */
    RVM_ASSERT(RVM_Captbl_Add(RVM_CAPTBL_VIRT1, 0, RVM_BOOT_CAPTBL, RVM_Vmmd_Sig_Cap, RVM_SIG_FLAG_SND)==0);
    RVM_LOG_S("Init:Delegated system call send endpoint to virtual machine RVM_PROC_VIRT1 \r\n");
    /* Vector endpoint - this is a special one */
    RVM_ASSERT(RVM_Captbl_Add(RVM_CAPTBL_VIRT1, 1, RVM_BOOT_CTVIRTEP0, 0, RVM_SIG_FLAG_SND|RVM_SIG_FLAG_RCV)==0);
    RVM_LOG_S("Init:Delegated system call send endpoint to virtual machine RVM_PROC_VIRT1 \r\n");

}
/* End Function:RVM_Boot_Virtcap_Init ****************************************/

/* Begin Function:RVM_Boot_Captbl_Init ****************************************
Description : Initialize the capability tables of all processes.
Input       : None.
Output      : None.
Return      : None.
******************************************************************************/
void RVM_Boot_Captbl_Init(void)
{

    /* Initializing captbl for process: Proc1 */
    /* Event kernel capability */
    RVM_ASSERT(RVM_Captbl_Kern(RVM_CAPTBL_PROC1, 0, RVM_BOOT_CAPTBL, RVM_BOOT_INIT_KERN, RVM_KERN_EVT_LOCAL_TRIG, RVM_KERN_EVT_LOCAL_TRIG)==0);
    RVM_LOG_S("Init:Delegated kernel capability for event sending to process RVM_PROC_PROC1 capability table position 0 \r\n");
    /* Ports */
    RVM_ASSERT(RVM_Captbl_Add(RVM_CAPTBL_PROC1, 1, RVM_BOOT_CTINV0, 0, RVM_INV_FLAG_ACT)==0);
    RVM_LOG_S("Init:Delegated invocation port RVM_PROC_PROC2_INV_INV1 to process RVM_PROC_PROC1 capability table position 1 \r\n");
    /* Receive endpoints */
    RVM_ASSERT(RVM_Captbl_Add(RVM_CAPTBL_PROC1, 2, RVM_BOOT_CTRECV0, 0, RVM_SIG_FLAG_SND|RVM_SIG_FLAG_RCV)==0);
    RVM_LOG_S("Init:Delegated receive endpoint RVM_PROC_PROC1_RECV_RECV1 to process RVM_PROC_PROC1 capability table position 2 \r\n");
    /* Send endpoints */
    /* Vector endpoints */
    /* Initializing captbl for process: Proc2 */
    /* Event kernel capability */
    RVM_ASSERT(RVM_Captbl_Kern(RVM_CAPTBL_PROC2, 0, RVM_BOOT_CAPTBL, RVM_BOOT_INIT_KERN, RVM_KERN_EVT_LOCAL_TRIG, RVM_KERN_EVT_LOCAL_TRIG)==0);
    RVM_LOG_S("Init:Delegated kernel capability for event sending to process RVM_PROC_PROC2 capability table position 0 \r\n");
    /* Ports */
    /* Receive endpoints */
    RVM_ASSERT(RVM_Captbl_Add(RVM_CAPTBL_PROC2, 1, RVM_BOOT_CTRECV0, 1, RVM_SIG_FLAG_SND|RVM_SIG_FLAG_RCV)==0);
    RVM_LOG_S("Init:Delegated receive endpoint RVM_PROC_PROC2_RECV_RECV1 to process RVM_PROC_PROC2 capability table position 1 \r\n");
    /* Send endpoints */
    RVM_ASSERT(RVM_Captbl_Add(RVM_CAPTBL_PROC2, 2, RVM_BOOT_CTRECV0, 0, RVM_SIG_FLAG_SND)==0);
    RVM_LOG_S("Init:Delegated send endpoint RVM_PROC_PROC1_RECV_RECV1 to process RVM_PROC_PROC2 capability table position 2 \r\n");
    /* Vector endpoints */
    RVM_ASSERT(RVM_Captbl_Add(RVM_CAPTBL_PROC2, 3, RVM_BOOT_CTVECT0, 0, RVM_SIG_FLAG_RCV)==0);
    RVM_LOG_S("Init:Delegated vector endpoint RVM_BOOT_VECT_TIM1 to process RVM_PROC_PROC2 capability table position 3 \r\n");
    /* Initializing captbl for process: Virt1 */
    /* Ports */
    /* Receive endpoints */
    /* Send endpoints */
    RVM_ASSERT(RVM_Captbl_Add(RVM_CAPTBL_VIRT1, 2, RVM_BOOT_CTRECV0, 0, RVM_SIG_FLAG_SND)==0);
    RVM_LOG_S("Init:Delegated send endpoint RVM_PROC_PROC1_RECV_RECV1 to process RVM_PROC_VIRT1 capability table position 2 \r\n");
    /* Vector endpoints */
}
/* End Function:RVM_Boot_Captbl_Init *****************************************/

/* Begin Function:RVM_Boot_Pgtbl_Init *****************************************
Description : Initialize the page tables of all processes.
Input       : None.
Output      : None.
Return      : None.
******************************************************************************/
void RVM_Boot_Pgtbl_Init(void)
{

    /* Constructing page tables for process: Proc1 */
    RVM_ASSERT(RVM_Pgtbl_Con(RVM_PGTBL_PROC1_N0, 0x0, RVM_PGTBL_PROC1_N1, RVM_PGTBL_ALL_PERM)==0);
    RVM_LOG_S("Init:Constructed page table child RVM_PGTBL_PROC1_N1 into page table parent RVM_PGTBL_PROC1_N0 @ position 0x0 \r\n");
    RVM_ASSERT(RVM_Pgtbl_Con(RVM_PGTBL_PROC1_N0, 0x1, RVM_PGTBL_PROC1_N2, RVM_PGTBL_ALL_PERM)==0);
    RVM_LOG_S("Init:Constructed page table child RVM_PGTBL_PROC1_N2 into page table parent RVM_PGTBL_PROC1_N0 @ position 0x1 \r\n");
    RVM_ASSERT(RVM_Pgtbl_Con(RVM_PGTBL_PROC1_N0, 0x7, RVM_PGTBL_PROC1_N3, RVM_PGTBL_ALL_PERM)==0);
    RVM_LOG_S("Init:Constructed page table child RVM_PGTBL_PROC1_N3 into page table parent RVM_PGTBL_PROC1_N0 @ position 0x7 \r\n");

    /* Constructing page tables for process: Proc2 */
    RVM_ASSERT(RVM_Pgtbl_Con(RVM_PGTBL_PROC2_N0, 0x1, RVM_PGTBL_PROC2_N1, RVM_PGTBL_ALL_PERM)==0);
    RVM_LOG_S("Init:Constructed page table child RVM_PGTBL_PROC2_N1 into page table parent RVM_PGTBL_PROC2_N0 @ position 0x1 \r\n");
    RVM_ASSERT(RVM_Pgtbl_Con(RVM_PGTBL_PROC2_N0, 0x4, RVM_PGTBL_PROC2_N2, RVM_PGTBL_ALL_PERM)==0);
    RVM_LOG_S("Init:Constructed page table child RVM_PGTBL_PROC2_N2 into page table parent RVM_PGTBL_PROC2_N0 @ position 0x4 \r\n");

    /* Constructing page tables for process: Virt1 */
    RVM_ASSERT(RVM_Pgtbl_Con(RVM_PGTBL_VIRT1_N0, 0x1, RVM_PGTBL_VIRT1_N1, RVM_PGTBL_ALL_PERM)==0);
    RVM_LOG_S("Init:Constructed page table child RVM_PGTBL_VIRT1_N1 into page table parent RVM_PGTBL_VIRT1_N0 @ position 0x1 \r\n");
    RVM_ASSERT(RVM_Pgtbl_Con(RVM_PGTBL_VIRT1_N0, 0x4, RVM_PGTBL_VIRT1_N2, RVM_PGTBL_ALL_PERM)==0);
    RVM_LOG_S("Init:Constructed page table child RVM_PGTBL_VIRT1_N2 into page table parent RVM_PGTBL_VIRT1_N0 @ position 0x4 \r\n");

    /* Mapping pages into page tables - RVM_PGTBL_PROC1_N0 */

    /* Mapping pages into page tables - RVM_PGTBL_PROC1_N1 */
    RVM_ASSERT(RVM_Pgtbl_Add(RVM_PGTBL_PROC1_N1, 0x0, \
                             RVM_PGTBL_READ|RVM_PGTBL_EXECUTE|RVM_PGTBL_CACHEABLE|RVM_PGTBL_BUFFERABLE|RVM_PGTBL_STATIC, \
                             RVM_BOOT_PGTBL, 0x0, 0x802)==0);
    RVM_LOG_S("Init:Added page addr 0x8020000 size 0x10000 to page table RVM_PGTBL_PROC1_N1 @ position 0x0 \r\n");

    /* Mapping pages into page tables - RVM_PGTBL_PROC1_N2 */
    RVM_ASSERT(RVM_Pgtbl_Add(RVM_PGTBL_PROC1_N2, 0x0, \
                             RVM_PGTBL_READ|RVM_PGTBL_WRITE|RVM_PGTBL_EXECUTE|RVM_PGTBL_CACHEABLE|RVM_PGTBL_BUFFERABLE|RVM_PGTBL_STATIC, \
                             RVM_BOOT_PGTBL, 0x0, 0x2002)==0);
    RVM_LOG_S("Init:Added page addr 0x20020000 size 0x10000 to page table RVM_PGTBL_PROC1_N2 @ position 0x0 \r\n");
    RVM_ASSERT(RVM_Pgtbl_Add(RVM_PGTBL_PROC1_N2, 0x1, \
                             RVM_PGTBL_READ|RVM_PGTBL_WRITE|RVM_PGTBL_EXECUTE|RVM_PGTBL_CACHEABLE|RVM_PGTBL_BUFFERABLE|RVM_PGTBL_STATIC, \
                             RVM_BOOT_PGTBL, 0x0, 0x2003)==0);
    RVM_LOG_S("Init:Added page addr 0x20030000 size 0x10000 to page table RVM_PGTBL_PROC1_N2 @ position 0x1 \r\n");

    /* Mapping pages into page tables - RVM_PGTBL_PROC1_N3 */
    RVM_ASSERT(RVM_Pgtbl_Add(RVM_PGTBL_PROC1_N3, 0x0, \
                             RVM_PGTBL_READ|RVM_PGTBL_WRITE|RVM_PGTBL_STATIC, \
                             RVM_BOOT_PGTBL, 0x0, 0xF000)==0);
    RVM_LOG_S("Init:Added page addr 0xf0000000 size 0x10000 to page table RVM_PGTBL_PROC1_N3 @ position 0x0 \r\n");

    /* Mapping pages into page tables - RVM_PGTBL_PROC2_N0 */

    /* Mapping pages into page tables - RVM_PGTBL_PROC2_N1 */
    RVM_ASSERT(RVM_Pgtbl_Add(RVM_PGTBL_PROC2_N1, 0x0, \
                             RVM_PGTBL_READ|RVM_PGTBL_EXECUTE|RVM_PGTBL_CACHEABLE|RVM_PGTBL_BUFFERABLE|RVM_PGTBL_STATIC, \
                             RVM_BOOT_PGTBL, 0x0, 0x803)==0);
    RVM_LOG_S("Init:Added page addr 0x8030000 size 0x10000 to page table RVM_PGTBL_PROC2_N1 @ position 0x0 \r\n");

    /* Mapping pages into page tables - RVM_PGTBL_PROC2_N2 */
    RVM_ASSERT(RVM_Pgtbl_Add(RVM_PGTBL_PROC2_N2, 0x0, \
                             RVM_PGTBL_READ|RVM_PGTBL_WRITE|RVM_PGTBL_EXECUTE|RVM_PGTBL_CACHEABLE|RVM_PGTBL_BUFFERABLE|RVM_PGTBL_STATIC, \
                             RVM_BOOT_PGTBL, 0x0, 0x2004)==0);
    RVM_LOG_S("Init:Added page addr 0x20040000 size 0x10000 to page table RVM_PGTBL_PROC2_N2 @ position 0x0 \r\n");

    /* Mapping pages into page tables - RVM_PGTBL_VIRT1_N0 */

    /* Mapping pages into page tables - RVM_PGTBL_VIRT1_N1 */
    RVM_ASSERT(RVM_Pgtbl_Add(RVM_PGTBL_VIRT1_N1, 0x0, \
                             RVM_PGTBL_READ|RVM_PGTBL_EXECUTE|RVM_PGTBL_CACHEABLE|RVM_PGTBL_BUFFERABLE|RVM_PGTBL_STATIC, \
                             RVM_BOOT_PGTBL, 0x0, 0x804)==0);
    RVM_LOG_S("Init:Added page addr 0x8040000 size 0x10000 to page table RVM_PGTBL_VIRT1_N1 @ position 0x0 \r\n");

    /* Mapping pages into page tables - RVM_PGTBL_VIRT1_N2 */
    RVM_ASSERT(RVM_Pgtbl_Add(RVM_PGTBL_VIRT1_N2, 0x0, \
                             RVM_PGTBL_READ|RVM_PGTBL_WRITE|RVM_PGTBL_EXECUTE|RVM_PGTBL_CACHEABLE|RVM_PGTBL_BUFFERABLE|RVM_PGTBL_STATIC, \
                             RVM_BOOT_PGTBL, 0x0, 0x2005)==0);
    RVM_LOG_S("Init:Added page addr 0x20050000 size 0x10000 to page table RVM_PGTBL_VIRT1_N2 @ position 0x0 \r\n");

}
/* End Function:RVM_Boot_Pgtbl_Init ******************************************/

/* Begin Function:RVM_Boot_Thd_Init *******************************************
Description : Initialize the all threads.
Input       : None.
Output      : None.
Return      : None.
******************************************************************************/
void RVM_Boot_Thd_Init(void)
{
    rvm_ptr_t Init_Stack_Addr;

    /* Initializing thread for process: Proc1 */
    RVM_ASSERT(RVM_Thd_Sched_Bind(RVM_PROC_PROC1_THD_THD1, RVM_Sftd_Thd_Cap, RVM_Sftd_Sig_Cap, RVM_PROC_PROC1_THD_THD1, 17)==0);
    Init_Stack_Addr=RVM_Stack_Init(0x2002F000, 0x1000, 0x8020000, 0x8020020);
    RVM_ASSERT(RVM_Thd_Exec_Set(RVM_PROC_PROC1_THD_THD1, 0x8020000, Init_Stack_Addr, 0x1234)==0);
    RVM_ASSERT(RVM_Thd_Time_Xfer(RVM_PROC_PROC1_THD_THD1, RVM_BOOT_INIT_THD, RVM_THD_INF_TIME)==RVM_THD_INF_TIME);
    RVM_LOG_S("Init:Initialized thread RVM_PROC_PROC1_THD_THD1 process RVM_PROC_PROC1 Entry 0x8020000 Stack 0x2002f000-0x1000 Param 0x1234 \r\n");

    /* Initializing thread for process: Proc2 */
    RVM_ASSERT(RVM_Thd_Sched_Bind(RVM_PROC_PROC2_THD_THD1, RVM_Sftd_Thd_Cap, RVM_Sftd_Sig_Cap, RVM_PROC_PROC2_THD_THD1, 16)==0);
    Init_Stack_Addr=RVM_Stack_Init(0x2004F000, 0x1000, 0x8030000, 0x8030040);
    RVM_ASSERT(RVM_Thd_Exec_Set(RVM_PROC_PROC2_THD_THD1, 0x8030000, Init_Stack_Addr, 0x1234)==0);
    RVM_ASSERT(RVM_Thd_Time_Xfer(RVM_PROC_PROC2_THD_THD1, RVM_BOOT_INIT_THD, RVM_THD_INF_TIME)==RVM_THD_INF_TIME);
    RVM_LOG_S("Init:Initialized thread RVM_PROC_PROC2_THD_THD1 process RVM_PROC_PROC2 Entry 0x8030000 Stack 0x2004f000-0x1000 Param 0x1234 \r\n");

    /* Initializing thread for process: Virt1 */
    RVM_ASSERT(RVM_Thd_Sched_Bind(RVM_PROC_VIRT1_THD_VECT, RVM_Sftd_Thd_Cap, RVM_Sftd_Sig_Cap, RVM_PROC_VIRT1_THD_VECT|RVM_VIRT_THDID_MARKER, 3)==0);
    Init_Stack_Addr=RVM_Stack_Init(0x2005FC00, 0x400, 0x8040000, 0x8040040);
    RVM_ASSERT(RVM_Thd_Exec_Set(RVM_PROC_VIRT1_THD_VECT, 0x8040000, Init_Stack_Addr, 0x0)==0);
    RVM_ASSERT(RVM_Thd_Time_Xfer(RVM_PROC_VIRT1_THD_VECT, RVM_BOOT_INIT_THD, RVM_THD_INF_TIME)==RVM_THD_INF_TIME);
    RVM_LOG_S("Init:Initialized thread RVM_PROC_VIRT1_THD_VECT process RVM_PROC_VIRT1 Entry 0x8040000 Stack 0x2005fc00-0x400 Param 0x0 \r\n");

    RVM_ASSERT(RVM_Thd_Sched_Bind(RVM_PROC_VIRT1_THD_USER, RVM_Sftd_Thd_Cap, RVM_Sftd_Sig_Cap, RVM_PROC_VIRT1_THD_USER|RVM_VIRT_THDID_MARKER, 2)==0);
    RVM_ASSERT(RVM_Thd_Hyp_Set(RVM_PROC_VIRT1_THD_USER, 0x2005F400)==0);
    Init_Stack_Addr=RVM_Stack_Init(0x2005F800, 0x400, 0x8040020, 0x8040040);
    RVM_ASSERT(RVM_Thd_Exec_Set(RVM_PROC_VIRT1_THD_USER, 0x8040020, Init_Stack_Addr, 0x0)==0);
    RVM_ASSERT(RVM_Thd_Time_Xfer(RVM_PROC_VIRT1_THD_USER, RVM_BOOT_INIT_THD, RVM_THD_INF_TIME)==RVM_THD_INF_TIME);
    RVM_LOG_S("Init:Initialized thread RVM_PROC_VIRT1_THD_USER process RVM_PROC_VIRT1 Entry 0x8040020 Stack 0x2005f800-0x400 Param 0x0 \r\n");

}
/* End Function:RVM_Boot_Thd_Init ********************************************/

/* Begin Function:RVM_Boot_Inv_Init *******************************************
Description : Initialize the all invocations.
Input       : None.
Output      : None.
Return      : None.
******************************************************************************/
void RVM_Boot_Inv_Init(void)
{
    rvm_ptr_t Init_Stack_Addr;

    /* Initializing invocation for process: Proc1 */
    /* Initializing invocation for process: Proc2 */
    Init_Stack_Addr=RVM_Stack_Init(0x2004E000, 0x1000, 0x8030020, 0x8030040);
    RVM_ASSERT(RVM_Inv_Set(RVM_PROC_PROC2_INV_INV1, 0x8030020, Init_Stack_Addr, 1)==0);
    RVM_LOG_S("Init:Initialized invocation RVM_PROC_PROC2_INV_INV1 process RVM_PROC_PROC2 Entry 0x8030020 Stack 0x2004e000-0x1000\r\n");

    /* Initializing invocation for process: Virt1 */
}
/* End Function:RVM_Boot_Inv_Init ********************************************/

/* Begin Function:RVM_Boot_Kobj_Init ******************************************
Description : Initialize all kernel objects at boot-time.
Input       : None.
Output      : None.
Return      : None.
******************************************************************************/
void RVM_Boot_Kobj_Init(void)
{
    RVM_Boot_Virtcap_Init();
    RVM_Boot_Captbl_Init();
    RVM_Boot_Pgtbl_Init();
    RVM_Boot_Thd_Init();
    RVM_Boot_Inv_Init();
    RVM_Virt_Crt(RVM_Virt_DB, (struct RVM_Virt_Map*)RVM_Virt_Map_DB, 1);
}
/* End Function:RVM_Boot_Kobj_Init *******************************************/

/* End Of File ***************************************************************/

/* Copyright (C) Evo-Devo Instrum. All rights reserved ***********************/

