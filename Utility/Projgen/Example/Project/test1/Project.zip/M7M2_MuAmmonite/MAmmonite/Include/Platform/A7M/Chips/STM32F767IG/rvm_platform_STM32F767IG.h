/******************************************************************************
Filename   : rvm_platform_STM32F767IG.h
Author     : pry
Date       : 26/06/2017
Licence    : The Unlicense; see LICENSE for details.
Description: The configuration file for STM32F767IG. The values listed here should
             be in accordance with that in the kernel.
******************************************************************************/

/* Defines *******************************************************************/
/* The generator must be enabled to use this */
/* Kernel configurations - keep the same with the kernel *********************/
/* The virtual memory start address for the kernel objects */
#define RVM_KMEM_VA_START                               (0x2000C4C0)
/* The size of the kernel object virtual memory */
#define RVM_KMEM_SIZE                                   (0x2740)
/* The granularity of kernel memory allocation, order of 2 in bytes */
#define RVM_KMEM_SLOT_ORDER                             (4)
/* The maximum number of preemption priority levels in the system.
 * This parameter must be divisible by the word length - 32 is usually sufficient */
#define RVM_MAX_PREEMPT_PRIO                            (32)
/* Number of virtual priorities in the system */
#define RVM_MAX_PREEMPT_VPRIO                           (32)
/* Number of events */
#define RVM_EVT_NUM                                     (10)
/* Number of mappings */
#define RVM_MAP_NUM                                     (128)

/* Initial kernel object capability limit */
#define RVM_A7M_CAP_BOOT_FRONTIER                       (9)
/* Initial kernel object memory limit */
#define RVM_A7M_KMEM_BOOT_FRONTIER                      (0x840)
/* Number of MPU regions available */
#define RVM_A7M_MPU_REGIONS                             (8)
/* Init process's first thread's entry point address */
#define RVM_A7M_INIT_ENTRY                              (0x8010001)
/* Init process's first thread's stack address */
#define RVM_A7M_INIT_STACK                              (0x2001FFF0)
/* What is the FPU type? */
#define RVM_A7M_FPU_TYPE                                (RVM_A7M_FPU_FPV5_DP)
/* Interrupt flag address */
#define RVM_A7M_VECT_FLAG_ADDR                          (0x2000FE00)
/* Shared interrupt flag region address - always 512B memory for ARMv7-M */
#define RVM_A7M_EVT_FLAG_ADDR                           (0x2000FC00)
/* Syslib configurations *****************************************************/
/* Stack redundancy */
#define RVM_STACK_SAFE_RDCY                             (16)
/* Daemon process stack address and size, in bytes */
#define RVM_SFTD_STACK_BASE                             (0x2001E000)
#define RVM_SFTD_STACK_SIZE                             (0x1000)
#define RVM_TIMD_STACK_BASE                             (0x2001B000)
#define RVM_TIMD_STACK_SIZE                             (0x1000)
#define RVM_VMMD_STACK_BASE                             (0x2001D000)
#define RVM_VMMD_STACK_SIZE                             (0x1000)
#define RVM_VCTD_STACK_BASE                             (0x2001C000)
#define RVM_VCTD_STACK_SIZE                             (0x1000)

/* Config settings - modifications not needed for most cases */
/* How many VMs are allowed? */
#define RVM_MAX_VM_NUM                                  (16)
/* How many different virtual machine priorities are allowed? */
#define RVM_MAX_PREEMPT_VPRIO                           (32)

/* Maximum time allowed to set as period */
#define RVM_MAX_PERIOD                                  (10000)
/* Minimum time allowed to set as period */
#define RVM_MIN_PERIOD                                  (1)
/* The default value for timer interrupt frequency for a VM */
#define RVM_DEF_PERIOD                                  (1)

/* Is debugging output enabled? */
#define RVM_DEBUG_LOG                                   RVM_TRUE

#define RVM_A7M_USART1_TDR                              RVM_A7M_REG(0x40011000+0x28)
#define RVM_A7M_USART1_ISR                              RVM_A7M_REG(0x40011000+0x1C)

/* Print characters to console */
#define RVM_A7M_PUTCHAR(CHAR) \
do \
{ \
    RVM_A7M_USART1_TDR=(CHAR); \
    while((RVM_A7M_USART1_ISR&0x40)==0); \
} \
while(0)
/* End Defines ***************************************************************/

/* End Of File ***************************************************************/

/* Copyright (C) Evo-Devo Instrum. All rights reserved ***********************/

